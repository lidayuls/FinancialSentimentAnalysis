
- The FPB data is available at: https://huggingface.co/datasets/takala/financial_phrasebank
- The FiQA-SA data is available at: https://huggingface.co/datasets/pauri32/fiqa-2018
- The TFNS data is available at: https://huggingface.co/datasets/zeroshot/twitter-financial-news-sentiment
- The NWGI data is available at: https://huggingface.co/datasets/oliverwang15/news_with_gpt_instructions
- The FinanceMath data is available at: https://huggingface.co/datasets/yale-nlp/FinanceMath
- The EFSA data is available at: https://github.com/cty1934/EFSA